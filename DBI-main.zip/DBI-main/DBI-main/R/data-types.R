setOldClass("difftime")

setOldClass("AsIs")
