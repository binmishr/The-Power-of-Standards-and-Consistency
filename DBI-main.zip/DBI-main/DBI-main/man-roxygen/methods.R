#' @noMd
#' @name <%=method_name %>
#' @rdname <%=method_name %>
#' @description
#' \Sexpr[results=rd,stage=render]{DBI:::methods_as_rd("<%=method_name %>")}
NULL
